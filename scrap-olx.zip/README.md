# Simple scrap OLX for SemiNovos BH

### To extract categories
```python3 src/scrap.py```

### To save contacts
```python3 src/extract.py```
